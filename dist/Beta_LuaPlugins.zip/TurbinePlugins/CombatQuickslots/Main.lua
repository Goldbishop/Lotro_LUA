
import "TurbinePlugins.CombatQuickslots";

combatBar = CombatQuickslotBar();

Turbine.Shell.WriteLine( combatBat );