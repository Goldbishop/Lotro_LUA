
import "Turbine.Enum";
import "Turbine.LogLevel";

LogLevel = enum();

LogLevel.Debug = 0;
LogLevel.Information = 1;
LogLevel.Warning = 2;
LogLevel.Error = 3;
