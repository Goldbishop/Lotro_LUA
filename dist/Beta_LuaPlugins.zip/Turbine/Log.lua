
import "Turbine.Class";
import "Turbine.LogManager";

-- Create a global log object that is for the default logger.
Log = LogManager.GetLogger( "Default" );
